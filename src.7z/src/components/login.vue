<template lang="pug">
  #login
    input.username(placeholder="username")
    input.password(placeholder="password")
    button.submit(@click="commit") click to login

</template>
<script>


  export default {
    data() {
      return {

      }
    },
    created() {

    },
    methods: {
      commit(){

      }
    }
  }

</script>
<style lang="stylus" scoped>


</style>
