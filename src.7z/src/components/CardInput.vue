<template lang="pug">
  #card-input
    .info
      input.event(v-model="eventName" placeholder="input event name")
      input.start-time(v-model="startTime" placeholder="input start time")
      input.last-time(v-model="lastTime" placeholder="input last time")
      input.loc(v-model="location" placeholder="input location")
    .btn
      button(@click="addcard") add

</template>
<script>
import MapSearch from "./MapSearch.vue"
import ax from 'axios';

  export default {
    components: {
      MapSearch
    },

    data() {
      return {
        eventName: '',
        startTime: '',
        lastTime: '',
        location: ''
      }
    },
    created() {

    },
    methods: {
      addcard : function(){
        var cardl = {
          eventName: this.eventName,
          startTime: this.startTime,
          lastTime: this.lastTime,
          location: this.location
        }
        this.$emit('transferInfo', cardl);
      }
    }
  }


</script>
<style lang="stylus" scoped>
  #card-input
    border thin black solid
    .info
      display flex
      flex-direction column
    .btn
      display flex


</style>
