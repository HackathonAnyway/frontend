<template lang="pug">
#register
  input.username(placeholder="username")
  input.password(placeholder="password")
  button.submit(@click="commit") click to register

</template>
<script>

  import api from '../api'

  export default {
    data() {
      return {

      }
    },
    created() {

    },
    methods: {
      commit(){

      }
    }
  }

</script>
<style lang="stylus" scoped>

</style>
