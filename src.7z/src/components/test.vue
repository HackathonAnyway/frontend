<template lang="pug">
  #test
    .navigation
      h1 MagicList
    .cards
      button(@click="inputflag=!inputflag").add add a event
      .input(v-if="inputflag")
        CardInput(@transferInfo="addCard")
      MapSearch
        //button add
      .showcards(v-for="(card, index) in cards")
        Card(@deletecard="deleteacard", :index="index", :eventName="card.eventName", :startTime="card.startTime", :lastTime="card.lastTime", :location="card.location")
    .submit
      button.submitlst(@click="submit") submit your list

</template>

<script>
  import $ from '../../static/jquery-3.2.1.min.js'
  import '../../static/animate.css'
  import 'vue2-animate/dist/vue2-animate.min.css'
  import MapSearch from "./MapSearch.vue"
  import CardInput from "./CardInput.vue"
  import Card from "./Card.vue"
  import ax from "axios"
   /*
  $(document).ready(function(){
    console.log("document is ready");
    $(".greet").css('color', '#000');
  })*/

  export default{

    name: 'Index',
    components: {
      MapSearch,
      CardInput,
      Card
    },
    data(){
      return {
        inputflag: false,

        cards:[
          {
            eventName: '1',
            startTime: 'qwe',
            lastTime: 'eee',
            location: 'www'
          },
          {
            eventName: '2',
            startTime: 'weqwe',
            lastTime: 'eqwe',
            location: 'qwewq'
          },
          {
            eventName: '3',
            startTime: 'weqwe',
            lastTime: 'eqwe',
            location: 'qwewq'
          },
          {
            eventName: '4',
            startTime: 'weqwe',
            lastTime: 'eqwe',
            location: 'qwewq'
          },
        ]
      }
    },
    methods: {
      addCard (cardl){
        this.cards.push(cardl);
      },
      deleteacard(index){
        console.log(index);
        this.cards.splice(index, 1);
      },
      submit (){
        console.log("submit");
        /*ax({
          method: "POST",
          url: '127.0.0.1',
          data: {

          }
        });*/

      }

    }

  }
</script>

<style lang="stylus">
  #test
    display flex
    flex-direction column
    margin 30px
    min-height 600px
    box-shadow 0 20px 50px 3px #666
    align-items center

    .navigation
      display flex
      justify-content center
      width 100%
      height 100px

      h1
        font-size 30px
        color #444
        margin-left 15px


    .cards
      max-width 500px
      display flex
      flex-direction column
      .add
        align-items flex-end


    .detail
      display flex
      width 80%
      flex-direction column
      justify-content center
        //border solid thin black
    .submitlist
      height 30px

</style>
